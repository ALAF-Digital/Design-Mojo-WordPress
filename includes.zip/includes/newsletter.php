<!-- NewsLetter -->
<section class="NewsLetter">
  <div class="container">
    <div class="row text-center">
      <div class="Newsltter-Head">
        <h1>Subscribe <span>newsletter</span></h1>
        <h1><span>and get</span> Exclusive Offers</h1>
      </div>
      <div class="col-md-8 mx-auto">
        <form action="">
          <div class="form">
            <input type="text" class="form-control" placeholder="Enter your email here" />
            <button class="btn">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<!-- NewsLetter End -->